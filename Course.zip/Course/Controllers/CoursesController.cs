﻿using Microsoft.AspNetCore.Mvc;
using Course.Models;

public class CoursesController : Controller
{
    private static List<Education> Courses = new List<Education>
    {
        new Education (1, "Introduction to Computer Science","Foundational understanding of computer science concepts, algorithms, and programming.", DateTime.Now, DateTime.Now.AddMonths(3)),
        new Education (2, "Financial Accounting Basics", "Fundamentals of financial accounting, principles of bookkeeping, and financial statement analysis.", DateTime.Now, DateTime.Now.AddMonths(2)),
        new Education (3, "Creative Writing Workshop", "Explore and develop creative writing skills, including storytelling, character development, and writing techniques." , DateTime.Now, DateTime.Now.AddMonths(4)),
        new Education (4, "Introduction to Astrophysics", "Basic principles of astronomy and astrophysics, including celestial mechanics and the life cycle of stars.", DateTime.Now, DateTime.Now.AddMonths(5))

    };

    public IActionResult Index()
    {
        if (Courses == null)
        {
            Console.WriteLine("Courses is null.");
            Courses = new List<Education>();
        }

        Console.WriteLine($"Number of courses: {Courses.Count}");

        return View(Courses);
    }


}

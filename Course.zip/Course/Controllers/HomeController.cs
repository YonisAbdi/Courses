using Course.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Course.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private static List<Education> educations = new List<Education>
        {
            new Education (1, "Introduction to Computer Science","Foundational understanding of computer science concepts, algorithms, and programming.", DateTime.Now, DateTime.Now.AddMonths(3)),
            new Education (2, "Financial Accounting Basics", "Fundamentals of financial accounting, principles of bookkeeping, and financial statement analysis.", DateTime.Now, DateTime.Now.AddMonths(2)),
            new Education (3, "Creative Writing Workshop", "Explore and develop creative writing skills, including storytelling, character development, and writing techniques." , DateTime.Now, DateTime.Now.AddMonths(4)),
            new Education (4, "Introduction to Astrophysics", "Basic principles of astronomy and astrophysics, including celestial mechanics and the life cycle of stars.", DateTime.Now, DateTime.Now.AddMonths(5))
        };

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View(educations);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
